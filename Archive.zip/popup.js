(function() {

    'use strict';

    function Popup () {
        this.init();
    }

    Popup.prototype.init = function init() {
        this.bindLoopInput();
        this.bindRenderModeSelect();
        this.bindAlternateProfileInput();
    };

    Popup.prototype.bindRenderModeSelect = function bindSelect() {
        var i = document.querySelector('select');

        i.addEventListener('change', function(e) {
            sendMessage({
                renderMode: i.value
            });
        });
    };

    Popup.prototype.bindLoopInput = function bindSelect() {
        var i = document.getElementById('input-loop');

        i.addEventListener('change', function(e) {
            sendMessage({
                loopEnabled: i.checked
            });
        });
    };

    Popup.prototype.bindAlternateProfileInput =
        function bindAlternateProfileInput() {
            var i = document.getElementById('input-alternate-profile');

            i.addEventListener('change', function(e) {
                sendMessage({
                    alternateProfile: i.checked
                });
            });
    };

    /**
     * Sends chrome message.
     */
    function sendMessage(data) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(
                tabs[0].id,
                {
                    data: data
                },
                function() {}
            );
        });
    }

    /**
     * Gets stored state of loop option.
     */
    chrome.storage.sync.get('loopEnabled', function(items) {
        var i = document.getElementById('input-loop');

        i.checked = items.loopEnabled;
    });

    /**
     * Gets stored state of alternate profile page layout.
     */
    chrome.storage.sync.get('alternateProfile', function(items) {
        var i = document.getElementById('input-alternate-profile');

        i.checked = items.alternateProfile;
    });

    /**
     * Opens all links in new tab.
     */
    window.addEventListener('click',function(e){
        if (e.target.href) {
            chrome.tabs.create({url:e.target.href});
        }
    });

    /**
     * Shows current version.
     */
    document.getElementById('version').innerText = 'v' +
        chrome.runtime.getManifest().version;

    return new Popup();

})();
